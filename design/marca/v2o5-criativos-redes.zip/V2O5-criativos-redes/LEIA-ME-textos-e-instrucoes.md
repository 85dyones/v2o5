# Alinhamento dos perfis da V2O5 (31/10/2026)

Posicionamento único, para repetir em todo lugar: **"V2O5 | Eficiência comercial e operacional com tecnologia."** Consultoria on-line, atendimento em todo o Brasil (decisão do Dyones, 31/10), diagnóstico gratuito de 45 minutos. Nome fixo: **V2O5 Vendas e Tecnologia**. Site: `https://www.v2o5.com.br`. Sem endereço de rua em nenhum perfil. Nada de "Curitiba e região" nos textos; Curitiba aparece só onde a plataforma exige um local.

Eu não consigo editar esses perfis: o Windsor só tem Meta Ads e Perfil da Empresa conectados, e a Meta recusou o acesso da conta de anúncios ao conector de IA. Tudo abaixo está pronto para colar.

## Criativos prontos (`design/marca/redes/`)

Gerados por `node design/ferramentas/gerar-redes.mjs` (Geist, papel, tinta e as quatro cores do vanádio; a rota com quatro paradas é o motivo da marca).

| Rede | Peça | Arquivo | Onde usar |
|---|---|---|---|
| Todas | Avatar 1080 x 1080 (o bloco âmbar da marca; a rede corta em círculo) | `avatar-1080.png` | Foto do perfil no Instagram, LinkedIn e Facebook |
| LinkedIn | Banner da página, 1128 x 191 (arquivo em 2x) | `linkedin-banner-empresa-1128x191.png` | Capa da página da empresa (o logo cobre o canto inferior esquerdo; o texto começa à direita dele) |
| LinkedIn | Banner pessoal, 1584 x 396 | `linkedin-banner-pessoal-1584x396.png` | Perfil do Dyones |
| Facebook | Capa 1640 x 624 (2x de 820 x 312) | `facebook-capa-1640x624.png` | Capa da página; o avatar cobre o canto inferior esquerdo e o celular corta as laterais, por isso o texto fica no centro |
| Instagram | Capas dos destaques, 1080 x 1920 (6) | `instagram-destaque-{metodo,solucoes,precos,case,16-vara,diagnostico}-1080x1920.png` | Destaques: Método, Soluções, Preços, Case, 16ª Vara, Diagnóstico |
| Google | Logo 720 x 720 e foto de capa 1024 x 576 | `google-logo-720.png`, `google-capa-1024x576.png` | Perfil da Empresa (logo e foto de capa) |
| Instagram | Modelo de post 1080 x 1350 e de story 1080 x 1920 | `instagram-modelo-post-1080x1350.png`, `instagram-modelo-story-1080x1920.png` | Base visual da rotina semanal |

Pendentes: banner do LinkedIn com o seu retrato (falta a foto, pendência 24b), arte de capa para vídeo e o conjunto de peças do primeiro mês, que a rotina semanal produz.

## O que está errado hoje

| Perfil | Hoje | Problema |
|---|---|---|
| LinkedIn | Nome "V2O5 ConsutorIA" (com erro de grafia), tagline "Consultoria em IA aplicada à rotina do seu negócio", site **v205.com.br** (com zero-cinco, não é o domínio), 1 seguidor, 1 funcionário, sem publicação | Posicionamento antigo, domínio errado, sem prova nenhuma |
| Instagram | Não consegui ler (o Instagram bloqueou a consulta pública); você descreveu como desatualizado e parado | Conferir nome, bio e link junto com o checklist abaixo |
| Facebook | Não existe página | Falta para anúncios, WhatsApp e `sameAs` |
| Perfil da Empresa | Não verificado, texto diz "de Curitiba" e "Curitiba e região" | Trocar pelo texto abaixo |

O endereço do LinkedIn precisa continuar `v2o5-consutoria` (é o que está no `sameAs` do site). Trocar o endereço da página exige mudar o schema junto.

## LinkedIn (página da empresa)

- **Nome:** V2O5 Vendas e Tecnologia
- **Tagline (115 caracteres):** Eficiência comercial e operacional com tecnologia. Diagnóstico gratuito de 45 minutos, on-line, para todo o Brasil.
- **Site:** https://www.v2o5.com.br
- **Setor:** Serviços e consultoria de TI (ou manter Tecnologia, informação e internet)
- **Botão:** "Fale conosco" para https://www.v2o5.com.br/diagnostico
- **Sobre:**
  > A V2O5 ajuda pequenas e médias empresas a vender e operar com menos atrito. Começamos por um diagnóstico gratuito de 45 minutos com o fundador, achamos o gargalo e resolvemos um de cada vez: presença digital, sites integrados ao CRM e ao WhatsApp, agentes de IA e automação.
  >
  > Cada solução tem escopo fechado e preço de referência público em v2o5.com.br/precos. O método roda em produção na Motors Store, revenda de seminovos, e na triagem do WhatsApp da 16ª Vara Cível, as duas em Curitiba. Atendimento on-line em todo o Brasil.
- **Especialidades:** Presença digital local, Sites e integrações, Agente de IA para WhatsApp, Automação de processos, CRM com WhatsApp, Rastreamento de conversões
- **Logo:** `design/marca/bloco-1080.png`. **Banner** 1128 x 191 px: ainda não existe; pedir ao design.
- **Primeira publicação (apresentação):** o que a V2O5 faz, como o diagnóstico funciona e o link. Sem número que não seja do case.
- **Perfil do fundador (Dyones Oliveira):** cargo "Fundador, V2O5 Vendas e Tecnologia", empresa atual ligada à página, mesmo sobre curto e o link do site; ele é o autor dos guias e o canal de maior alcance.

## Instagram (@v2o5_consultoria)

- **Nome (campo pesquisável, 31 caracteres):** V2O5 | Consultoria e tecnologia
- **Usuário:** manter `v2o5_consultoria` (está no `sameAs`).
- **Categoria:** Consultoria empresarial (igual ao Perfil da Empresa).
- **Bio (131 caracteres):**
  ```
  Eficiência comercial e operacional com tecnologia.
  Diagnóstico gratuito de 45 minutos, on-line, em todo o Brasil.
  Agende pelo link.
  ```
- **Link:** https://www.v2o5.com.br/diagnostico?utm_source=instagram&utm_medium=bio
- **Foto:** `design/marca/bloco-1080.png`
- **Destaques (capas no papel #F2F1EC com o símbolo):** Método, Soluções, Preços, Case Motors, Case 16ª Vara, Diagnóstico. O da 16ª (17/11) junta os stories do case `/cases/16-vara-civel`, sem número. A capa pedida pelo Dyones leva a marca do TJPR com "16ª VARA CÍVEL" embaixo, na D-DIN PRO (DIN aberta, da linha da URW DIN do manual do TJPR), e foi entregue a ele fora deste repositório, que é público: o manual de marca do TJPR reserva a assinatura setorial à Coordenadoria de Comunicação Social, e a marca só entra aqui se a autorização da vara cobrir o uso. Sem a marca, a capa é `instagram-destaque-16-vara-1080x1920.png`.
- **Fixados (3):** o que fazemos, como funciona o diagnóstico, o case da Motors.
- **Conta profissional:** conectar à página do Facebook (a mesma, abaixo), ativar botão de contato por WhatsApp.
- **Publicações antigas:** arquivar as que usam a marca ou o texto de "ConsultorIA" e preços antigos; não apagar o que não for conflitante.

## Facebook (criar a página)

Eu não consigo criar a página. Passo a passo (Meta Business Suite ou facebook.com/pages/create):

- **Nome:** V2O5 Vendas e Tecnologia
- **Nome de usuário:** `v2o5vendasetecnologia` (se estiver ocupado, `v2o5consultoria`)
- **Categoria:** Consultoria empresarial
- **Sobre (193 caracteres, o limite da bio é maior no campo Descrição):**
  > Eficiência comercial e operacional com tecnologia. A V2O5 acha o gargalo, simplifica o processo e implementa site, automação e IA. Diagnóstico gratuito de 45 minutos, on-line, em todo o Brasil.
- **Contato:** WhatsApp (41) 99808-9550, diagnostico@v2o5.com.br, site https://www.v2o5.com.br
- **Endereço:** não preencher (negócio on-line). Horário: o mesmo do atendimento.
- **Botão de ação:** "Enviar mensagem" pelo WhatsApp, ou "Agendar" para /diagnostico.
- **Foto e capa:** bloco-1080 e uma capa 820 x 360 px (a fazer).
- **Depois de criada:** vincular ao Instagram, conectar o WhatsApp Business, aceitar os termos de anúncios de formulário se for usar, e me passar a URL. Eu coloco no `sameAs` e, com sua autorização, defino a mensagem de boas-vindas da página pelo Windsor.

## Perfil da Empresa no Google (precisa da sua confirmação para eu alterar)

Texto novo para o campo "Descrição" (hoje fala em Curitiba):
> A V2O5 Vendas e Tecnologia é uma consultoria on-line que ajuda pequenas e médias empresas de todo o Brasil a vender e operar com menos atrito. Começamos por um diagnóstico gratuito de 45 minutos e resolvemos um gargalo de cada vez: presença digital, sites integrados ao CRM e ao WhatsApp, agentes de IA e automação. Cada solução tem escopo fechado e preço de referência público. O método já roda em produção na Motors Store, revenda de seminovos, e na triagem do WhatsApp da 16ª Vara Cível, as duas em Curitiba.

- **Área de atendimento:** Brasil (negócio sem atendimento no local). Endereço de rua oculto.
- **Verificação:** continua pendente; sem ela o resto não aparece.
- Responda "pode" e eu aplico a descrição e a área pelo Windsor. Categorias e serviços, um a um.

## Ordem

1. Facebook (cria, vincula) → 2. Instagram (bio, nome, link, foto) → 3. LinkedIn (nome, tagline, site certo, sobre) → 4. Perfil da Empresa (descrição, área, verificação) → 5. a rotina social começa a publicar.
